const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const loginWithTwitch = async (twitchProfile) => {
  let user = await User.findOne({ twitchId: twitchProfile.id });
  if (!user) {
    user = new User({
      twitchId: twitchProfile.id,
      displayName: twitchProfile.display_name,
      profileImageUrl: twitchProfile.profile_image_url
    });
    await user.save();
  }
  const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
  return { user, token };
};

module.exports = { loginWithTwitch };

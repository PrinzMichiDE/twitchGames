const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
dotenv.config();

const authRoutes = require('./routes/authRoutes');

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const User = require('./models/User');
const Channel = require('./models/Channel');

app.use(express.json());

app.post('/api/saveUserData', async (req, res) => {
  const { twitchId, name, email, profileImageUrl, createdAt } = req.body;
  try {
    const user = await User.findOneAndUpdate(
      { twitchId },
      { name, email, profileImageUrl, createdAt, lastUpdated: new Date() },
      { upsert: true, new: true }
    );
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: 'Error saving user data' });
  }
});

app.post('/api/saveChannelData', async (req, res) => {
  const { broadcasterId, broadcasterName, gameName, title, language, tags } = req.body;
  try {
    const channel = await Channel.findOneAndUpdate(
      { broadcasterId },
      { broadcasterName, gameName, title, language, tags, lastUpdated: new Date() },
      { upsert: true, new: true }
    );
    res.status(200).json(channel);
  } catch (error) {
    res.status(500).json({ error: 'Error saving channel data' });
  }
});

app.get('/api/getFollowersData', async (req, res) => {
    try {
      const followersData = await Followers.find({}).sort({ date: -1 });
      res.status(200).json(followersData);
    } catch (error) {
      res.status(500).json({ error: 'Error fetching followers data' });
    }
  });
  

app.listen(5000, () => {
  console.log('Server is running on port 5000');
});

// backend/models/User.js
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  login: { type: String, required: true },
  display_name: { type: String, required: true },
  email: { type: String, required: true },
  description: { type: String },
  profile_image_url: { type: String },
  view_count: { type: Number },
  created_at: { type: Date },
});

module.exports = mongoose.models.User || mongoose.model('User', UserSchema);
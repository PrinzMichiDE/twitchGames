// pages/api/twitch/details.js
const axios = require('axios');
const { getSession } = require('next-auth/react');
const connectDB = require('../../../backend/db/connect');
const User = require('../../../backend/models/User');
const Channel = require('../../../backend/models/Channel');

module.exports = async (req, res) => {
  await connectDB();

  const session = await getSession({ req });

  if (!session) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }

  const accessToken = session.accessToken;
  const userId = '81703152'; // Replace this with a dynamic way to get the user ID if needed

  try {
    const userResponse = await axios.get(`https://api.twitch.tv/helix/users?id=${userId}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Client-Id': process.env.TWITCH_CLIENT_ID,
      },
    });

    const userInfo = userResponse.data.data[0];
    await User.updateOne({ id: userId }, userInfo, { upsert: true });

    const channelResponse = await axios.get(`https://api.twitch.tv/helix/channels?broadcaster_id=${userId}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Client-Id': process.env.TWITCH_CLIENT_ID,
      },
    });

    const channelInfo = channelResponse.data.data[0];
    await Channel.updateOne({ broadcaster_id: userId }, channelInfo, { upsert: true });

    const subscriptionsResponse = await axios.get(`https://api.twitch.tv/helix/subscriptions?broadcaster_id=${userId}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Client-Id': process.env.TWITCH_CLIENT_ID,
      },
    });

    const subscriptionsInfo = subscriptionsResponse.data;

    const followersResponse = await axios.get(`https://api.twitch.tv/helix/channels/followers?broadcaster_id=${userId}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Client-Id': process.env.TWITCH_CLIENT_ID,
      },
    });

    const followersInfo = followersResponse.data;

    const bitsResponse = await axios.get('https://api.twitch.tv/helix/bits/leaderboard', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Client-Id': process.env.TWITCH_CLIENT_ID,
      },
    });

    const bitsInfo = bitsResponse.data;

    const extensionsResponse = await axios.get('https://api.twitch.tv/helix/analytics/extensions', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Client-Id': process.env.TWITCH_CLIENT_ID,
      },
    });

    const extensionsInfo = extensionsResponse.data;

    const gamesResponse = await axios.get('https://api.twitch.tv/helix/analytics/games', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Client-Id': process.env.TWITCH_CLIENT_ID,
      },
    });

    const gamesInfo = gamesResponse.data;

    res.status(200).json({
      userInfo,
      channelInfo,
      subscriptionsInfo,
      followersInfo,
      bitsInfo,
      extensionsInfo,
      gamesInfo,
    });
  } catch (error) {
    console.error('API Error:', error.response ? error.response.data : error.message);
    res.status(500).json({ error: error.response ? error.response.data : 'Internal Server Error' });
  }
};

// pages/index.js
import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import FollowersChart from '../components/FollowersChart';
import { Card, Row, Col } from 'react-bootstrap';

export default function Dashboard() {
  const { data: session } = useSession();
  const [data, setData] = useState(null);

  useEffect(() => {
    if (session) {
      fetch('/api/twitch/details')
        .then(response => response.json())
        .then(data => setData(data))
        .catch(error => console.error('Error fetching details:', error));
    }
  }, [session]);

  if (!session) {
    return <p>You need to be authenticated to view this page.</p>;
  }

  if (!data) {
    return <p>Loading...</p>;
  }

  const { userInfo, channelInfo, subscriptionsInfo, followersInfo, bitsInfo, extensionsInfo, gamesInfo } = data;

  return (
    <Layout>
      <h1>Dashboard Overview</h1>
      <Row>
        <Col>
          <Card>
            <Card.Header>Profile</Card.Header>
            <Card.Body>
              <Card.Img variant="top" src={userInfo.profile_image_url} />
              <Card.Text>Name: {userInfo.display_name}</Card.Text>
              <Card.Text>Email: {userInfo.email}</Card.Text>
              <Card.Text>Description: {userInfo.description}</Card.Text>
              <Card.Text>View Count: {userInfo.view_count}</Card.Text>
              <Card.Text>Created At: {new Date(userInfo.created_at).toLocaleDateString()}</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col>
          <Card>
            <Card.Header>Channel Information</Card.Header>
            <Card.Body>
              <Card.Text>Broadcaster Name: {channelInfo.broadcaster_name}</Card.Text>
              <Card.Text>Game: {channelInfo.game_name}</Card.Text>
              <Card.Text>Title: {channelInfo.title}</Card.Text>
              <Card.Text>Language: {channelInfo.broadcaster_language}</Card.Text>
              <Card.Text>Tags: {channelInfo.tags.join(', ')}</Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <Card.Header>Followers</Card.Header>
            <Card.Body>
              <Card.Text>Total Followers: {followersInfo.total}</Card.Text>
              <FollowersChart followersData={followersInfo} />
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
}

// components/Layout.js
import Link from 'next/link';
import { Navbar, Nav } from 'react-bootstrap';

const Layout = ({ children }) => (
  <>
    <Navbar bg="dark" variant="dark" expand="lg">
      <Navbar.Brand href="/">Dashboard</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="mr-auto">
          <Link href="/" passHref><Nav.Link>Overview</Nav.Link></Link>
          <Link href="/profile" passHref><Nav.Link>Profile</Nav.Link></Link>
          <Link href="/channel" passHref><Nav.Link>Channel</Nav.Link></Link>
          <Link href="/subscribers" passHref><Nav.Link>Subscribers</Nav.Link></Link>
          <Link href="/followers" passHref><Nav.Link>Followers</Nav.Link></Link>
          <Link href="/bits" passHref><Nav.Link>Bits</Nav.Link></Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
    <div className="container mt-3">
      {children}
    </div>
  </>
);

export default Layout;

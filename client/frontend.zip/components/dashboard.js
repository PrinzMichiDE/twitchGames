import { useSession } from 'next-auth/react';
import Link from 'next/link';
import Layout from '../components/Layout';

export default function Dashboard() {
  const { data: session } = useSession();

  if (!session) {
    return (
      <Layout>
        <div>Please sign in to access the dashboard.</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <h1>Dashboard</h1>
      <ul>
        <li><Link href="/create-lobby">Create Lobby</Link></li>
        <li><Link href="/join-lobby">Join Lobby</Link></li>
        <li><Link href="/create-game">Create Game</Link></li>
        <li><Link href="/games">Game Store</Link></li>
        <li><Link href="/create-overlay">Create Overlay</Link></li>
        <li><Link href="/overlays">Overlay Store</Link></li>
      </ul>
    </Layout>
  );
}
